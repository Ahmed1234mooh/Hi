// دوال مساعدة للتطبيق
class AppUtils {
  // عرض الإشعارات
  static showToast(message, type = "info", duration = 3000) {
    // إزالة الإشعارات السابقة
    const existingToasts = document.querySelectorAll(".toast")
    existingToasts.forEach((toast) => toast.remove())

    // إنشاء الإشعار الجديد
    const toast = document.createElement("div")
    toast.className = `toast ${type}`
    toast.textContent = message

    // تحديد لون الإشعار حسب النوع
    const colors = {
      success: "bg-green-600",
      error: "bg-red-600",
      warning: "bg-yellow-600",
      info: "bg-blue-600",
    }

    toast.className = `fixed bottom-4 left-1/2 transform -translate-x-1/2 ${
      colors[type] || colors.info
    } text-white px-6 py-3 rounded-lg shadow-lg z-50 text-sm font-medium`

    document.body.appendChild(toast)

    // إزالة الإشعار بعد المدة المحددة
    setTimeout(() => {
      if (toast.parentNode) {
        toast.remove()
      }
    }, duration)

    // اهتزاز خفيف للإشعارات المهمة
    if (type === "success" || type === "error") {
      this.vibrate(100)
    }
  }

  // اهتزاز الجهاز
  static vibrate(duration = 100) {
    if (navigator.vibrate) {
      navigator.vibrate(duration)
    }
  }

  // تأكيد الإجراء
  static async confirm(message, title = "تأكيد") {
    return new Promise((resolve) => {
      if (navigator.notification && navigator.notification.confirm) {
        navigator.notification.confirm(
          message,
          (buttonIndex) => {
            resolve(buttonIndex === 1) // 1 = نعم, 2 = لا
          },
          title,
          ["نعم", "لا"],
        )
      } else {
        resolve(confirm(message))
      }
    })
  }

  // عرض تنبيه
  static alert(message, title = "تنبيه") {
    if (navigator.notification && navigator.notification.alert) {
      navigator.notification.alert(message, null, title, "موافق")
    } else {
      alert(message)
    }
  }

  // تنسيق الأرقام
  static formatNumber(number, decimals = 2) {
    if (isNaN(number)) return "0"
    return Number.parseFloat(number).toFixed(decimals)
  }

  // تنسيق العملة
  static formatCurrency(amount) {
    return `${this.formatNumber(amount)} ج.م`
  }

  // التحقق من صحة البريد الإلكتروني
  static isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  // التحقق من صحة رقم الهاتف
  static isValidPhone(phone) {
    const phoneRegex = /^[0-9+\-\s()]+$/
    return phoneRegex.test(phone) && phone.length >= 10
  }

  // تنظيف النص
  static sanitizeText(text) {
    if (!text) return ""
    return text.toString().trim().replace(/[<>]/g, "")
  }

  // تحويل النص إلى رقم
  static toNumber(value, defaultValue = 0) {
    const num = Number.parseFloat(value)
    return isNaN(num) ? defaultValue : num
  }

  // إنشاء معرف فريد
  static generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2)
  }

  // نسخ النص إلى الحافظة
  static async copyToClipboard(text) {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(text)
        this.showToast("تم نسخ النص", "success")
      } else {
        // طريقة بديلة للأجهزة القديمة
        const textArea = document.createElement("textarea")
        textArea.value = text
        document.body.appendChild(textArea)
        textArea.select()
        document.execCommand("copy")
        document.body.removeChild(textArea)
        this.showToast("تم نسخ النص", "success")
      }
    } catch (err) {
      console.error("Error copying text:", err)
      this.showToast("فشل في نسخ النص", "error")
    }
  }

  // تحميل ملف
  static downloadFile(content, filename, contentType = "application/json") {
    const blob = new Blob([content], { type: contentType })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  // قراءة ملف
  static readFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = (e) => resolve(e.target.result)
      reader.onerror = (e) => reject(e)
      reader.readAsText(file)
    })
  }

  // التحقق من الاتصال بالإنترنت
  static isOnline() {
    return navigator.onLine
  }

  // مراقبة حالة الاتصال
  static onConnectionChange(callback) {
    window.addEventListener("online", () => callback(true))
    window.addEventListener("offline", () => callback(false))
  }

  // تحسين الأداء - تأخير التنفيذ
  static debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }

  // تحسين الأداء - تقييد التنفيذ
  static throttle(func, limit) {
    let inThrottle
    return function (...args) {
      if (!inThrottle) {
        func.apply(this, args)
        inThrottle = true
        setTimeout(() => (inThrottle = false), limit)
      }
    }
  }

  // تحديث شريط الحالة
  static updateStatusBar(color = "#1e40af") {
    if (window.StatusBar) {
      window.StatusBar.backgroundColorByHexString(color)
    }
  }

  // إخفاء لوحة المفاتيح
  static hideKeyboard() {
    if (window.Keyboard && window.Keyboard.hide) {
      window.Keyboard.hide()
    } else {
      // طريقة بديلة
      document.activeElement.blur()
    }
  }

  // عرض لوحة المفاتيح
  static showKeyboard() {
    if (window.Keyboard && window.Keyboard.show) {
      window.Keyboard.show()
    }
  }

  // التحقق من نوع الجهاز
  static getDeviceType() {
    const userAgent = navigator.userAgent.toLowerCase()
    if (userAgent.includes("android")) return "android"
    if (userAgent.includes("iphone") || userAgent.includes("ipad")) return "ios"
    return "web"
  }

  // التحقق من حجم الشاشة
  static getScreenSize() {
    const width = window.innerWidth
    if (width < 640) return "sm"
    if (width < 768) return "md"
    if (width < 1024) return "lg"
    return "xl"
  }

  // تحسين التمرير
  static smoothScrollTo(element, duration = 300) {
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "center",
      })
    }
  }

  // إدارة التحميل
  static showLoading(message = "جاري التحميل...") {
    const loading = document.createElement("div")
    loading.id = "app-loading"
    loading.className = "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    loading.innerHTML = `
      <div class="bg-white rounded-lg p-6 text-center">
        <div class="loading-spinner mx-auto mb-4"></div>
        <p class="text-gray-700">${message}</p>
      </div>
    `
    document.body.appendChild(loading)
  }

  static hideLoading() {
    const loading = document.getElementById("app-loading")
    if (loading) {
      loading.remove()
    }
  }
}

// تصدير الدوال للاستخدام العام
window.AppUtils = AppUtils
window.showToast = AppUtils.showToast.bind(AppUtils)
window.vibrate = AppUtils.vibrate.bind(AppUtils)
window.confirm = AppUtils.confirm.bind(AppUtils)
window.formatNumber = AppUtils.formatNumber.bind(AppUtils)
window.formatCurrency = AppUtils.formatCurrency.bind(AppUtils)
