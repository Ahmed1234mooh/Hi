// تهيئة Cordova والتطبيق
document.addEventListener("deviceready", onDeviceReady, false)

function onDeviceReady() {
  console.log("Cordova is ready")

  // إعداد شريط الحالة
  const StatusBar = window.StatusBar // Declare the variable before using it
  if (StatusBar) {
    StatusBar.styleDefault()
    StatusBar.overlaysWebView(false)
    StatusBar.backgroundColorByHexString("#1e40af")
  }

  // إخفاء شاشة البداية
  if (navigator.splashscreen) {
    setTimeout(() => {
      navigator.splashscreen.hide()
    }, 1000)
  }

  // منع الرجوع للخلف في الصفحة الرئيسية
  document.addEventListener("backbutton", onBackKeyDown, false)

  // تهيئة التخزين المحلي
  initializeLocalStorage()
}

function onBackKeyDown(e) {
  const currentPage = window.location.pathname

  if (currentPage.includes("index.html") || currentPage === "/") {
    // في الصفحة الرئيسية - اسأل عن الخروج
    navigator.notification.confirm(
      "هل تريد الخروج من التطبيق؟",
      (buttonIndex) => {
        if (buttonIndex === 1) {
          navigator.app.exitApp()
        }
      },
      "تأكيد الخروج",
      ["نعم", "لا"],
    )
  } else {
    // في صفحة أخرى - ارجع للصفحة الرئيسية
    window.location.href = "index.html"
  }

  e.preventDefault()
  return false
}

function initializeLocalStorage() {
  // تهيئة البيانات الأساسية إذا لم تكن موجودة
  if (!localStorage.getItem("customers")) {
    localStorage.setItem("customers", JSON.stringify([]))
  }

  if (!localStorage.getItem("dailyRounds")) {
    localStorage.setItem("dailyRounds", JSON.stringify({}))
  }

  if (!localStorage.getItem("archivedWeeks")) {
    localStorage.setItem("archivedWeeks", JSON.stringify([]))
  }

  console.log("Local storage initialized")
}

// دوال مساعدة للتطبيق
function showToast(message) {
  if (navigator.notification) {
    navigator.notification.alert(message, null, "إشعار", "موافق")
  } else {
    alert(message)
  }
}

function vibrate(duration = 100) {
  if (navigator.vibrate) {
    navigator.vibrate(duration)
  }
}
