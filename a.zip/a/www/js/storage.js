// نظام التخزين المحلي لتطبيق بوابة عملاء الألبان
class LocalStorage {
  constructor() {
    this.initializeStorage()
  }

  // تهيئة التخزين المحلي
  initializeStorage() {
    if (!localStorage.getItem("customers")) {
      localStorage.setItem("customers", JSON.stringify([]))
    }
    if (!localStorage.getItem("dailyRounds")) {
      localStorage.setItem("dailyRounds", JSON.stringify({}))
    }
    if (!localStorage.getItem("archivedWeeks")) {
      localStorage.setItem("archivedWeeks", JSON.stringify([]))
    }
  }

  // دوال إدارة العملاء
  getCustomers() {
    try {
      return JSON.parse(localStorage.getItem("customers") || "[]")
    } catch (e) {
      console.error("Error getting customers:", e)
      return []
    }
  }

  addCustomer(customer) {
    try {
      const customers = this.getCustomers()
      const newCustomer = {
        id: Date.now().toString(),
        name: customer.name,
        buffaloPrice: Number.parseFloat(customer.buffaloPrice) || 0,
        cowPrice: Number.parseFloat(customer.cowPrice) || 0,
        createdAt: new Date().toISOString(),
      }
      customers.push(newCustomer)
      localStorage.setItem("customers", JSON.stringify(customers))
      return { success: true, customer: newCustomer }
    } catch (e) {
      console.error("Error adding customer:", e)
      return { success: false, error: e.message }
    }
  }

  updateCustomer(id, customerData) {
    try {
      const customers = this.getCustomers()
      const index = customers.findIndex((c) => c.id === id)
      if (index === -1) {
        return { success: false, error: "العميل غير موجود" }
      }

      customers[index] = {
        ...customers[index],
        name: customerData.name,
        buffaloPrice: Number.parseFloat(customerData.buffaloPrice) || 0,
        cowPrice: Number.parseFloat(customerData.cowPrice) || 0,
        updatedAt: new Date().toISOString(),
      }

      localStorage.setItem("customers", JSON.stringify(customers))
      return { success: true, customer: customers[index] }
    } catch (e) {
      console.error("Error updating customer:", e)
      return { success: false, error: e.message }
    }
  }

  deleteCustomer(id) {
    try {
      const customers = this.getCustomers()
      const filteredCustomers = customers.filter((c) => c.id !== id)
      localStorage.setItem("customers", JSON.stringify(filteredCustomers))
      return { success: true }
    } catch (e) {
      console.error("Error deleting customer:", e)
      return { success: false, error: e.message }
    }
  }

  // دوال إدارة الجولات اليومية
  getDailyRounds() {
    try {
      return JSON.parse(localStorage.getItem("dailyRounds") || "{}")
    } catch (e) {
      console.error("Error getting daily rounds:", e)
      return {}
    }
  }

  getDailyRound(date, round) {
    try {
      const dailyRounds = this.getDailyRounds()
      const key = `${date}_${round}`
      return dailyRounds[key] || { customers: [], lastUpdated: null }
    } catch (e) {
      console.error("Error getting daily round:", e)
      return { customers: [], lastUpdated: null }
    }
  }

  saveDailyRound(date, round, data) {
    try {
      const dailyRounds = this.getDailyRounds()
      const key = `${date}_${round}`
      dailyRounds[key] = {
        ...data,
        lastUpdated: new Date().toISOString(),
      }
      localStorage.setItem("dailyRounds", JSON.stringify(dailyRounds))
      return { success: true }
    } catch (e) {
      console.error("Error saving daily round:", e)
      return { success: false, error: e.message }
    }
  }

  // دوال التقارير المالية
  getCustomerFinancialSummary(startDate, endDate) {
    try {
      const customers = this.getCustomers()
      const dailyRounds = this.getDailyRounds()
      const summary = []

      customers.forEach((customer) => {
        let totalBuffalo = 0
        let totalCow = 0
        let totalAmount = 0

        // البحث في جميع الجولات في الفترة المحددة
        Object.keys(dailyRounds).forEach((key) => {
          const [date, round] = key.split("_")
          if (date >= startDate && date <= endDate) {
            const roundData = dailyRounds[key]
            const customerData = roundData.customers?.find((c) => c.id === customer.id)
            if (customerData) {
              const buffalo = Number.parseFloat(customerData.buffalo) || 0
              const cow = Number.parseFloat(customerData.cow) || 0
              totalBuffalo += buffalo
              totalCow += cow
              totalAmount += buffalo * customer.buffaloPrice + cow * customer.cowPrice
            }
          }
        })

        if (totalBuffalo > 0 || totalCow > 0) {
          summary.push({
            id: customer.id,
            name: customer.name,
            buffaloPrice: customer.buffaloPrice,
            cowPrice: customer.cowPrice,
            totalBuffalo,
            totalCow,
            totalAmount,
          })
        }
      })

      return summary
    } catch (e) {
      console.error("Error getting financial summary:", e)
      return []
    }
  }

  // دوال الأرشيف
  getArchivedWeeks() {
    try {
      return JSON.parse(localStorage.getItem("archivedWeeks") || "[]")
    } catch (e) {
      console.error("Error getting archived weeks:", e)
      return []
    }
  }

  archiveCurrentWeek(weekStart, weekEnd, summary) {
    try {
      const archivedWeeks = this.getArchivedWeeks()
      const archive = {
        id: Date.now().toString(),
        weekStart,
        weekEnd,
        summary,
        archivedAt: new Date().toISOString(),
      }

      archivedWeeks.unshift(archive) // إضافة في المقدمة
      localStorage.setItem("archivedWeeks", JSON.stringify(archivedWeeks))

      // مسح البيانات الحالية للأسبوع
      this.clearWeekData(weekStart, weekEnd)

      return { success: true, archive }
    } catch (e) {
      console.error("Error archiving week:", e)
      return { success: false, error: e.message }
    }
  }

  clearWeekData(startDate, endDate) {
    try {
      const dailyRounds = this.getDailyRounds()
      const updatedRounds = {}

      Object.keys(dailyRounds).forEach((key) => {
        const [date] = key.split("_")
        if (date < startDate || date > endDate) {
          updatedRounds[key] = dailyRounds[key]
        }
      })

      localStorage.setItem("dailyRounds", JSON.stringify(updatedRounds))
      return { success: true }
    } catch (e) {
      console.error("Error clearing week data:", e)
      return { success: false, error: e.message }
    }
  }

  // دوال مساعدة
  exportData() {
    try {
      const data = {
        customers: this.getCustomers(),
        dailyRounds: this.getDailyRounds(),
        archivedWeeks: this.getArchivedWeeks(),
        exportedAt: new Date().toISOString(),
      }
      return JSON.stringify(data, null, 2)
    } catch (e) {
      console.error("Error exporting data:", e)
      return null
    }
  }

  importData(jsonData) {
    try {
      const data = JSON.parse(jsonData)
      if (data.customers) localStorage.setItem("customers", JSON.stringify(data.customers))
      if (data.dailyRounds) localStorage.setItem("dailyRounds", JSON.stringify(data.dailyRounds))
      if (data.archivedWeeks) localStorage.setItem("archivedWeeks", JSON.stringify(data.archivedWeeks))
      return { success: true }
    } catch (e) {
      console.error("Error importing data:", e)
      return { success: false, error: e.message }
    }
  }

  clearAllData() {
    try {
      localStorage.removeItem("customers")
      localStorage.removeItem("dailyRounds")
      localStorage.removeItem("archivedWeeks")
      this.initializeStorage()
      return { success: true }
    } catch (e) {
      console.error("Error clearing data:", e)
      return { success: false, error: e.message }
    }
  }
}

// دوال التاريخ والوقت
const DateUtils = {
  formatDate(date) {
    if (!date) return ""
    const d = new Date(date)
    return d.toLocaleDateString("ar-SA", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    })
  },

  formatDateTime(date) {
    if (!date) return ""
    const d = new Date(date)
    return d.toLocaleString("ar-SA", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })
  },

  getToday() {
    return new Date().toISOString().split("T")[0]
  },

  getWeekStart(date) {
    const d = new Date(date)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1) // الاثنين كبداية الأسبوع
    return new Date(d.setDate(diff)).toISOString().split("T")[0]
  },

  getWeekEnd(date) {
    const start = new Date(this.getWeekStart(date))
    start.setDate(start.getDate() + 6)
    return start.toISOString().split("T")[0]
  },

  getWeekDays(startDate) {
    const days = []
    const start = new Date(startDate)
    for (let i = 0; i < 7; i++) {
      const day = new Date(start)
      day.setDate(start.getDate() + i)
      days.push(day.toISOString().split("T")[0])
    }
    return days
  },

  dayNames: ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"],

  getDayName(date) {
    const d = new Date(date)
    return this.dayNames[d.getDay()]
  },

  addDays(date, days) {
    const d = new Date(date)
    d.setDate(d.getDate() + days)
    return d.toISOString().split("T")[0]
  },

  addWeeks(date, weeks) {
    return this.addDays(date, weeks * 7)
  },
}

// إنشاء مثيل عام للتخزين
const storage = new LocalStorage()

// تصدير الدوال للاستخدام العام
window.storage = storage
window.DateUtils = DateUtils

// دوال مساعدة للتوافق مع الكود الحالي
window.getCustomers = () => storage.getCustomers()
window.addCustomer = (customer) => storage.addCustomer(customer)
window.updateCustomer = (id, customer) => storage.updateCustomer(id, customer)
window.deleteCustomer = (id) => storage.deleteCustomer(id)
window.getDailyRound = (date, round) => storage.getDailyRound(date, round)
window.saveDailyRound = (date, round, data) => storage.saveDailyRound(date, round, data)
window.getCustomerFinancialSummary = (start, end) => storage.getCustomerFinancialSummary(start, end)
window.getArchivedWeeks = () => storage.getArchivedWeeks()
window.archiveCurrentWeek = (start, end, summary) => storage.archiveCurrentWeek(start, end, summary)
window.formatDate = DateUtils.formatDate
window.getWeekStart = DateUtils.getWeekStart
window.getWeekEnd = DateUtils.getWeekEnd
window.getWeekDays = DateUtils.getWeekDays
window.dayNames = DateUtils.dayNames
window.getDayName = DateUtils.getDayName
