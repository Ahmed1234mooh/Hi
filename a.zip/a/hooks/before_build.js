#!/usr/bin/env node

// Hook للتحقق من المتطلبات قبل البناء

const fs = require("fs")
const path = require("path")

module.exports = (context) => {
  console.log("Running before_build hook...")

  // التحقق من وجود الملفات المطلوبة
  const requiredFiles = [
    "www/index.html",
    "www/customers.html",
    "www/daily-round.html",
    "www/reports.html",
    "www/js/storage.js",
    "www/js/utils.js",
    "www/js/cordova-init.js",
    "www/css/app.css",
  ]

  const projectRoot = context.opts.projectRoot
  const missingFiles = []

  requiredFiles.forEach((file) => {
    const filePath = path.join(projectRoot, file)
    if (!fs.existsSync(filePath)) {
      missingFiles.push(file)
    }
  })

  if (missingFiles.length > 0) {
    console.error("Missing required files:")
    missingFiles.forEach((file) => console.error(`  - ${file}`))
    process.exit(1)
  }

  // التحقق من إعدادات config.xml
  const configPath = path.join(projectRoot, "config.xml")
  if (fs.existsSync(configPath)) {
    const configContent = fs.readFileSync(configPath, "utf8")

    // التحقق من معرف التطبيق
    if (!configContent.includes('id="com.milkportal.app"')) {
      console.warn("Warning: App ID might not be set correctly in config.xml")
    }

    // التحقق من الإصدار
    if (!configContent.includes('version="1.0.0"')) {
      console.warn("Warning: App version might not be set correctly in config.xml")
    }
  }

  // إنشاء معلومات البناء
  const buildInfo = {
    buildDate: new Date().toISOString(),
    version: "1.0.0",
    platform: context.opts.platforms[0] || "unknown",
    cordovaVersion: context.cordova.version,
  }

  const buildInfoPath = path.join(projectRoot, "www", "build-info.json")
  fs.writeFileSync(buildInfoPath, JSON.stringify(buildInfo, null, 2))

  console.log("before_build hook completed successfully!")
  console.log(`Building for platform: ${buildInfo.platform}`)
  console.log(`Build date: ${buildInfo.buildDate}`)
}
