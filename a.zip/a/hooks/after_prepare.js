#!/usr/bin/env node

// Hook لتحسين التطبيق بعد التحضير

const fs = require("fs")
const path = require("path")

module.exports = (context) => {
  console.log("Running after_prepare hook...")

  // تحسين ملفات HTML للإنتاج
  const wwwPath = path.join(context.opts.projectRoot, "www")
  const platformPath = path.join(
    context.opts.projectRoot,
    "platforms",
    "android",
    "app",
    "src",
    "main",
    "assets",
    "www",
  )

  if (fs.existsSync(platformPath)) {
    console.log("Optimizing HTML files for production...")

    // إزالة console.log من ملفات JavaScript
    const jsFiles = ["js/storage.js", "js/utils.js", "js/cordova-init.js"]

    jsFiles.forEach((file) => {
      const filePath = path.join(platformPath, file)
      if (fs.existsSync(filePath)) {
        let content = fs.readFileSync(filePath, "utf8")
        // إزالة console.log في الإنتاج
        content = content.replace(/console\.log$$[^)]*$$;?/g, "")
        fs.writeFileSync(filePath, content)
        console.log(`Optimized ${file}`)
      }
    })

    // تحسين ملفات HTML
    const htmlFiles = ["index.html", "customers.html", "daily-round.html", "reports.html"]

    htmlFiles.forEach((file) => {
      const filePath = path.join(platformPath, file)
      if (fs.existsSync(filePath)) {
        let content = fs.readFileSync(filePath, "utf8")
        // إزالة التعليقات الزائدة
        content = content.replace(/<!--[\s\S]*?-->/g, "")
        // تقليل المسافات الزائدة
        content = content.replace(/\s+/g, " ")
        fs.writeFileSync(filePath, content)
        console.log(`Optimized ${file}`)
      }
    })
  }

  console.log("after_prepare hook completed successfully!")
}
